# Saburi Vue Utils

`saburi-vue-utils` is a shared UI component and utility library for Saburi-based applications. It provides a standardized set of Vuetify components, controllers, and helper functions to ensure consistency across different projects.

## 🚀 Getting Started

### Installation

This library is distributed as a tarball. To install it in a hosting application:

1.  Copy the `saburi-vue-utils-x.x.x.tgz` file into the hosting project (e.g., in a `libs/` folder).
2.  Run the following command in the hosting project:
    ```bash
    npm install ./libs/saburi-vue-utils-x.x.x.tgz
    ```

## 🛠 Features

- **Standardized Components:** Includes `CrudForm`, `CrudTable`, `SDatePicker`, `SNumberInput`, and more.
- **Base Controllers:** Shared logic via `RootController` and `SearchController`.
- **Navigation Utilities:** Helper functions for generating routes and navigation structures.
- **Vuetify Configuration:** Pre-configured Vuetify settings and aliases (`STextField`, `STextarea`, etc.).
- **API Integration:** Standardized Axios-based API client with support for global headers and base URLs.

## 📦 Development & Distribution

### Building the Library
To compile the library for distribution:
```bash
npm run build
```
This generates the `dist/` folder containing the UMD and ESM bundles.

### Creating a Distribution Tarball
To create a package for sharing with other projects:
```bash
npm pack
```
This command generates a `.tgz` file (e.g., `saburi-vue-utils-1.0.0.tgz`).

### Project Structure
- `src/components/`: Vue UI components.
- `src/root/`: Base controllers and store logic.
- `src/nav/`: Navigation and routing utilities.
- `src/search/`: Generic search and list logic.
- `src/utils/`: Helper functions and HTTP methods.
- `src/plugins/`: Shared Vuetify configuration.

## ⚙️ Configuration

When installing the plugin in a host application, you can provide global configuration:

```javascript
import SaburiVueUtils from 'saburi-vue-utils'

app.use(SaburiVueUtils, {
  apiBaseUrl: 'https://api.example.com/',
  authStore: useAuthStore, // Optional: Pinia store for authentication
  tenantStore: useTenantStore, // Optional: Pinia store for tenant management
  getHeaders: () => ({ ... }) // Optional: Function to provide dynamic headers
})
```

## 📐 Dialog & Table Conventions

`saburi-vue-utils` provides standardized modal containers (`SDialog`, `SDetailsDialog`) and enhanced data tables (`SDataTable`, `Search`/`s-search`) to enforce uniform UI styling and architectural conventions.

### 1. Dialog File Naming Convention
Dialogs should follow the uniform entity naming convention matching other domain files:
- **View / Table:** `XXX.vue` or `XXXs.vue` (e.g., `EbulkPaymentRequests.vue`, `Policies.vue`)
- **Controller:** `XXXController.ts`
- **Model:** `XXXModel.ts`
- **Nav:** `XXXNav.ts`
- **Store:** `XXXStore.ts`
- **Dialog:** **`XXXDialog.vue`** (e.g., `EbulkPaymentRequestDialog.vue`, `PolicyDialog.vue`, `PaymentDialog.vue`)

### 2. Backend Calling Conventions in Dialogs
- **Zero Direct Axios / httpMethods Calls in Dialogs:** Dialog components must **never** import or invoke `axios` or raw HTTP methods directly.
- **Store / Controller Delegation:** Any backend queries (e.g., loading detailed records or executing actions like assessments) must be defined as actions in `XXXStore.ts` using `defineRootStore()` and invoked via `XXXController.ts`.
- **Base URL Prefix:** Endpoints defined in stores should **not** include the `api/` prefix (e.g., `ebulk-payment-requests/${id}/details`), as `api/` is already part of the base API URL configured in `main.ts`.

### 3. `SDetailsDialog` Component (`s-details-dialog`)
`SDetailsDialog` provides a schema-driven master-detail viewer with standard Vuetify 3 styling:

```vue
<template>
  <s-details-dialog
    :model-value="props.modelValue"
    @update:model-value="emit('update:modelValue', $event)"
    :title="`Policy Details - ${props.item?.policyNumber}`"
    icon="mdi-file-document-outline"
    :max-width="850"
    :item="props.item"
    :summary-cards="summaryCards"
    :sections="sections"
    :detail-tables="detailTables"
    :success-msg="successMsg"
    :error-msg="errorMsg"
    @close="close"
  >
    <!-- Optional custom cell formatter overrides -->
    <template #item.customColumn="{ item: row }">
      <span>{{ row.customField }}</span>
    </template>
  </s-details-dialog>
</template>
```

#### Supported Props:
- `summaryCards`: Array of `{ label, key, value, format, color, cols, sm, md }`
- `sections`: Array of `{ title, icon, fields: [{ label, key, cols, sm, isNumeric, isDate, isDateTime, formatter, chip, chipColor }] }`
- `detailTables`: Single table object or array of table objects `{ title, icon, items, headers, loading, searchable, hideDefaultFooter, actions: [...] }`.
  - **Single Table:** Renders a clean table with action buttons and record counts.
  - **Multiple Tables (>1):** Automatically generates a tabbed interface (`v-tabs` + `v-window`) with count badges and per-tab actions.

### 4. Table Header Configurations (`SDataTable` & `Search`)
Headers in `XXXNav.ts` and `detailHeaders` support rich styling:
- **Chips:**
  ```typescript
  {
    title: "Status",
    key: "status",
    chip: true,
    chipColor: (val: any) => (val === "ACTIVE" ? "success" : "warning"),
    chipVariant: "flat" // optional: 'flat', 'tonal', 'outlined'
  }
  ```
- **Clickable Links:**
  ```typescript
  {
    title: "Bulk Ref",
    key: "bulkPaymentReference",
    clickable: true, // or link: true
    click: (item: any) => openDetailsDialog(item)
  }
  ```
- **Formatters:**
  - `formatter: (val, item) => string`
  - `rowValueFormatter: (item) => string`
  - `isNumeric: true` (auto formats numbers with commas and calculates column totals in total row)
  - `isDate: true` / `isDateTime: true`
- **Total Row Behavior:**
  - Automatically added if numeric columns exist.
  - Non-numeric columns inherit values if all items share the exact same value, or remain clean blanks without rendering falsy chips (e.g., no red "No" chip).

