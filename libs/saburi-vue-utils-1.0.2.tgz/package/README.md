# Saburi Vue Utils

`saburi-vue-utils` is a shared UI component and utility library for Saburi-based applications. It provides a standardized set of Vuetify components, controllers, and helper functions to ensure consistency across different projects.

## 🚀 Getting Started

### Installation

This library is distributed as a tarball. To install it in a hosting application:

1.  Copy the `saburi-vue-utils-x.x.x.tgz` file into the hosting project (e.g., in a `libs/` folder).
2.  Run the following command in the hosting project:
    ```bash
    npm install ./libs/saburi-vue-utils-x.x.x.tgz
    ```

## 🛠 Features

- **Standardized Components:** Includes `CrudForm`, `CrudTable`, `SDatePicker`, `SNumberInput`, and more.
- **Base Controllers:** Shared logic via `RootController` and `SearchController`.
- **Navigation Utilities:** Helper functions for generating routes and navigation structures.
- **Vuetify Configuration:** Pre-configured Vuetify settings and aliases (`STextField`, `STextarea`, etc.).
- **API Integration:** Standardized Axios-based API client with support for global headers and base URLs.

## 📦 Development & Distribution

### Building the Library
To compile the library for distribution:
```bash
npm run build
```
This generates the `dist/` folder containing the UMD and ESM bundles.

### Creating a Distribution Tarball
To create a package for sharing with other projects:
```bash
npm pack
```
This command generates a `.tgz` file (e.g., `saburi-vue-utils-1.0.0.tgz`).

### Project Structure
- `src/components/`: Vue UI components.
- `src/root/`: Base controllers and store logic.
- `src/nav/`: Navigation and routing utilities.
- `src/search/`: Generic search and list logic.
- `src/utils/`: Helper functions and HTTP methods.
- `src/plugins/`: Shared Vuetify configuration.

## ⚙️ Configuration

When installing the plugin in a host application, you can provide global configuration:

```javascript
import SaburiVueUtils from 'saburi-vue-utils'

app.use(SaburiVueUtils, {
  apiBaseUrl: 'https://api.example.com/',
  authStore: useAuthStore, // Optional: Pinia store for authentication
  tenantStore: useTenantStore, // Optional: Pinia store for tenant management
  getHeaders: () => ({ ... }) // Optional: Function to provide dynamic headers
})
```
